# VANI Android Starter

A first native Android starter for VANI. It includes:
- Hindi speech input through Android's speech-recognition activity
- Text-to-speech responses
- Basic app launching, Settings, Dialer, and SMS composer intents
- Optional online AI request using a user-provided OpenAI API key
- GitHub Actions workflow to build and upload a debug APK

## Build on GitHub using only your phone

1. Create a public or private GitHub repository named `VANI`.
2. Upload the contents of this project ZIP to the repository root (make sure `.github/workflows/build-apk.yml` is included).
3. Open the repository's **Actions** tab.
4. Select **Build VANI Debug APK** and tap **Run workflow**. A push to `main` also starts a build.
5. Open the successful run and download the `VANI-debug-apk` artifact.
6. Extract the downloaded artifact ZIP and install `app-debug.apk` on your Android phone. You may need to allow installation from your browser/file manager.

## Important limitations in this starter

- This is the first working stage, not the final full assistant.
- Speech recognition starts when you tap the microphone. Always-on “Hey VANI” listening is not implemented yet.
- Flashlight currently opens Android Settings as a safe fallback; direct torch control will be added in a later stage.
- Calls use the dialer so the user confirms the call. SMS opens the messaging composer and does not send automatically.
- Contact-name matching, reminders, persistent background service, lock-screen activation, offline speech models, and advanced app controls are not implemented yet.
- Online AI uses the OpenAI Chat Completions API with model `gpt-4o-mini`. You need your own API key and an account with access/billing. API key storage here is a simple on-device preference, suitable only for a prototype; don't share the APK or device with untrusted people while a key is saved. Never commit keys to GitHub.
- Android, manufacturer battery rules, microphone permissions, and installed apps determine what can work in the background.

## Stack

Kotlin, Jetpack Compose, Android intents, Android speech recognition and TextToSpeech, GitHub Actions.
