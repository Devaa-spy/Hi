package com.vani.assistant

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

private val Navy = Color(0xFF071426)
private val Cyan = Color(0xFF42D9FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VaniApp() }
    }
}

@Composable
private fun VaniApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("vani_settings", Context.MODE_PRIVATE) }
    var command by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("Namaste! Main VANI hoon. Neeche mic dabakar command bolo.") }
    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    val tts = remember {
        TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Use Hindi when available; Android may fall back if the voice is not installed.
            }
        }
    }
    DisposableEffect(Unit) { onDispose { tts.shutdown() } }

    val micLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                command = spoken
                handleCommand(context, spoken) { reply ->
                    answer = reply
                    tts.language = Locale("hi", "IN")
                    tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "vani_reply")
                }
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, background = Navy, surface = Color(0xFF10233B),
        onBackground = Color.White, onSurface = Color.White
    )) {
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF06101F), Color(0xFF102B48), Color(0xFF071426)))
            )
        ) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(18.dp))
                Text("VANI", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Black, color = Cyan)
                Text("PERSONAL VOICE ASSISTANT", style = MaterialTheme.typography.labelMedium, color = Color.LightGray)
                Spacer(Modifier.height(24.dp))
                Surface(shape = RoundedCornerShape(28.dp), color = Color(0xCC10233B), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("VANI is ready", color = Cyan, style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(12.dp))
                        Text(answer, color = Color.White, style = MaterialTheme.typography.bodyLarge)
                        Spacer(Modifier.height(18.dp))
                        FilledTonalButton(
                            onClick = {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "VANI ko command dein")
                                }
                                try { micLauncher.launch(intent) }
                                catch (_: ActivityNotFoundException) {
                                    Toast.makeText(context, "Speech recognition service available nahi hai.", Toast.LENGTH_LONG).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(54.dp)
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Bolo: VANI")
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                OutlinedTextField(
                    value = command, onValueChange = { command = it },
                    label = { Text("Command type karein") },
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = {
                            if (command.isNotBlank()) handleCommand(context, command) { reply ->
                                answer = reply
                                tts.language = Locale("hi", "IN")
                                tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "vani_reply")
                            }
                        }) { Icon(Icons.Default.Send, contentDescription = "Send") }
                    }
                )
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { showSettings = !showSettings }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (showSettings) "AI settings band karein" else "Online AI settings")
                }
                if (showSettings) {
                    Spacer(Modifier.height(8.dp))
                    Text("OpenAI-compatible API key (optional)", color = Color.LightGray)
                    OutlinedTextField(
                        value = apiKey, onValueChange = { apiKey = it },
                        label = { Text("API key") }, modifier = Modifier.fillMaxWidth()
                    )
                    Button(onClick = {
                        prefs.edit().putString("api_key", apiKey.trim()).apply()
                        Toast.makeText(context, "Key is device par save ho gayi.", Toast.LENGTH_SHORT).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text("Save AI key") }
                    Button(
                        enabled = apiKey.isNotBlank() && command.isNotBlank() && !busy,
                        onClick = {
                            busy = true
                            Thread {
                                val reply = askOnlineAI(apiKey.trim(), command)
                                (context as? Activity)?.runOnUiThread {
                                    busy = false
                                    answer = reply
                                    tts.language = Locale("hi", "IN")
                                    tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "vani_ai_reply")
                                }
                            }.start()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "AI se jawab aa raha hai..." else "Ask online AI") }
                    Text("Note: API usage may cost money. Never publish your key on GitHub.", color = Color(0xFFFFD180), style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(18.dp))
                Text("Try commands", color = Cyan, style = MaterialTheme.typography.titleMedium)
                Text("• YouTube kholo\n• Chrome kholo\n• Settings kholo\n• Torch / flashlight kholo\n• 9876543210 ko call karo\n• 9876543210 ko message bhejo",
                    color = Color.LightGray, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                Spacer(Modifier.height(22.dp))
                Text("Wake phrase 'Hey VANI' and background listening are a later phase; this starter uses a mic button for reliable Android-compatible speech input.",
                    color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun handleCommand(context: Context, raw: String, respond: (String) -> Unit) {
    val text = raw.lowercase(Locale.ROOT)
    try {
        when {
            "youtube" in text -> {
                launchPackageOrWeb(context, "com.google.android.youtube", "https://www.youtube.com")
                respond("YouTube khol rahi hoon.")
            }
            "chrome" in text -> {
                launchPackageOrWeb(context, "com.android.chrome", "https://www.google.com")
                respond("Chrome kholne ki koshish kar rahi hoon.")
            }
            "setting" in text || "settings" in text -> {
                context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                respond("Settings khol rahi hoon.")
            }
            "flashlight" in text || "torch" in text -> {
                context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                respond("Settings khol di hain. Yahan se flashlight ya connected device settings control karein.")
            }
            "call" in text || "phone karo" in text -> {
                val number = Regex("\\+?[0-9][0-9 -]{7,14}[0-9]").find(raw)?.value?.replace(" ", "")?.replace("-", "")
                if (number != null) {
                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    respond("$number ke liye dialer khol diya. Call aap confirm kar sakte hain.")
                } else {
                    context.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    respond("Dialer khol diya. Number check karke call karein.")
                }
            }
            "message" in text || "sms" in text -> {
                val number = Regex("\\+?[0-9][0-9 -]{7,14}[0-9]").find(raw)?.value?.replace(" ", "")?.replace("-", "")
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse(if (number != null) "smsto:$number" else "smsto:")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                respond("Messages app khol di. Bhejne se pehle message check kar lein.")
            }
            "time" in text || "samay" in text || "kitne baje" in text -> {
                val time = java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())
                respond("Abhi $time baj rahe hain.")
            }
            else -> respond("Main is command ko abhi offline nahi samajh paayi. App kholne, settings, dialer, messages ya online AI ka use karein.")
        }
    } catch (e: Exception) {
        respond("Ye action nahi ho paaya. Phone permission ya supported app check karein.")
    }
}

private fun launchPackageOrWeb(context: Context, packageName: String, url: String) {
    val launch = context.packageManager.getLaunchIntentForPackage(packageName)
    if (launch != null) {
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launch)
    } else {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun askOnlineAI(apiKey: String, prompt: String): String {
    var connection: HttpURLConnection? = null
    return try {
        connection = (URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 20000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json")
        }
        val body = JSONObject()
            .put("model", "gpt-4o-mini")
            .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", "You are VANI, a concise Hindi/Hinglish Android voice assistant. Do not claim to perform phone actions you cannot perform.")).put(JSONObject().put("role", "user").put("content", prompt)))
            .put("temperature", 0.5)
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        if (connection.responseCode !in 200..299) {
            "AI request fail hua (${connection.responseCode}). API key, account access aur usage limit check karein."
        } else {
            JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
    } catch (e: Exception) {
        "Online AI connect nahi ho paaya. Internet aur API key check karein."
    } finally {
        connection?.disconnect()
    }
}
